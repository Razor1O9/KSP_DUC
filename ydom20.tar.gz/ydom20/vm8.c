#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include <bigint.h>
#include "stack8.h"

#define IMMEDIATE(x) ((x) & 0x00FFFFFF)
#define SIGN_EXTEND(i) ((i) & 0x00800000 ? (i) | 0xFF000000 : (i)) 

#define HALT		0
#define PUSHC		1
#define ADD 		2
#define SUB 		3
#define MUL 		4
#define DIV 		5
#define MOD 		6
#define RDINT		7
#define WRINT 		8
#define RDCHR 		9
#define WRCHR		10

#define PUSHG		11
#define POPG 		12
#define ASF		13
#define RSF		14
#define PUSHL		15
#define POPL		16

#define EQ      	17
#define NE      	18
#define LT      	19
#define LE      	20
#define GT      	21
#define GE      	22

#define JMP     	23
#define BRF     	24
#define BRT     	25

#define CALL		26
#define RET		27
#define DROP		28
#define PUSHR		29
#define POPR		30

#define DUP		31

#define NEW             32
#define GETF            33
#define PUTF            34

#define NEWA            35
#define GETFA           36
#define PUTFA           37

#define GETSZ           38

#define PUSHN           39
#define REFEQ           40
#define REFNE           41

/*the current version of VM*/
#define VERSION 	8

// DEBUG-option
#define INSPECT		1
#define LIST		2
#define BREAKPOINT	3
#define STEP		4
#define RUN		5
#define QUIT		6

// for instance read input
#define MAX 		11

// program memory
unsigned int *ps;
// break up program
static int halt = 0;

// program counter
static int pc = 0;
// current instruktion in debug mode
static unsigned int index = 0;
// set breakpoint in debug mode
static int breakpoint = -1;
// next instruktion in debug mode
static int step = 0; 

// it used in function break_point(char *x)
static int value = 0;

// it used in function read_line(char *str)
static int count = 0;

// it used in function run()
static int switcher = 1;

// Header control structures
/*typedef struct {
	char name[4];
	int version;
	int noi;
	int sda;
} header_t;

static header_t buffer;*/

int counter = 0;
int start_debug = 0;
int bin = 0;
int position = 0;

void instruktion(int i) {
	switch(ps[i] >> 24) {
		case HALT: printf("%.4d\thalt\n", i); break;
		case PUSHC: printf("%.4d\tpushc\t%d\n", i, SIGN_EXTEND(IMMEDIATE(ps[i]))); break;
		case ADD: printf("%.4d\tadd\n", i); break;
		case SUB: printf("%.4d\tsub\n", i); break;
		case MUL: printf("%.4d\tmul\n", i); break;
		case DIV: printf("%.4d\tdiv\n", i); break;
		case MOD: printf("%.4d\tmod\n", i); break;
		case RDINT: printf("%.4d\trdint\n", i); break;
		case WRINT: printf("%.4d\twrint\n", i); break;
		case RDCHR: printf("%.4d\trdchr\n", i); break;
		case WRCHR: printf("%.4d\twrchr\n", i); break;
		case PUSHG: printf("%.4d\tpushg\t%d\n", i, IMMEDIATE(ps[i])); break;
		case POPG: printf("%.4d\tpopg\t%d\n", i, IMMEDIATE(ps[i])); break;
		case ASF: printf("%.4d\tasf\t%d\n", i, IMMEDIATE(ps[i])); break;
		case RSF: printf("%.4d\trsf\t\n", i); break;
		case PUSHL: printf("%.4d\tpushl\t%d\n", i, SIGN_EXTEND(IMMEDIATE(ps[i]))); break;
		case POPL: printf("%.4d\tpopl\t%d\n", i, IMMEDIATE(ps[i])); break;
		case EQ: printf("%.4d\teq\t\n", i); break;
		case NE: printf("%.4d\tne\t\n", i); break;
		case LT: printf("%.4d\tlt\t\n", i); break;
		case LE: printf("%.4d\tls\t\n", i); break;
		case GT: printf("%.4d\tgt\t\n", i); break;
		case GE: printf("%.4d\tge\t\n", i); break;
		case JMP: printf("%.4d\tjmp\t\n", i); break;
		case BRF: printf("%.4d\tbrf\t\n", i); break;
		case BRT: printf("%.4d\tbrt\t\n", i); break;
		case CALL: printf("%.4d\tcall\t%d\n", i, IMMEDIATE(ps[i])); break;
		case RET: printf("%.4d\tret\t\n", i); break;
		case DROP: printf("%.4d\tdrop\t%d\n", i, IMMEDIATE(ps[i])); break;
		case PUSHR: printf("%.4d\tpushr\t\n", i); break;
		case POPR:  printf("%.4d\tpopr\t\n", i); break;
		case DUP: printf("%.4d\tdup\t\n", i); break;
		case NEW: printf("%.4d\tnew\t\n", i); break;
		case GETF: printf("%.4d\tgetf\t\n", i); break;
		case PUTF: printf("%.4d\tputf\t\n", i); break;
		case NEWA: printf("%.4d\tnewa\t\n", i); break;
		case GETFA: printf("%.4d\tgetfa\t\n", i); break;
		case PUTFA: printf("%.4d\tputfa\t\n", i); break;
		case GETSZ: printf("%.4d\tgetsz\t\n", i); break;
		case PUSHN: printf("%.4d\tpushn\t\n", i); break;
		case REFEQ: printf("%.4d\trefeq\t\n", i); break;
		case REFNE: printf("%.4d\trefne\t\n", i); break;
		default: printf("ir is something else\n"); exit(1); break;
	}
}

// stack operation
void exec(int ir) {
	/**value2 = Devisor --> z.B. Quotient = Dividend : Devisor*/
	/*or it used for buffer*/
	int value = 0;
	// int value2 = 0;
		switch((ir >> 24)) {
			case HALT: 
				halt = 1; break;
			case PUSHC: // push value ir ^ (1 << 24)
				bigFromInt(SIGN_EXTEND(IMMEDIATE(ir)));		
				pushObjRef(bip.res);
				break; 				
			case ADD: 
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				bigAdd();
				pushObjRef(bip.res); 
				break;
			case SUB: 
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				bigSub();
				pushObjRef(bip.res); 
				break;
			case MUL: 
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				bigMul();
				pushObjRef(bip.res);
				break;
			case DIV: 
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				bigDiv();
				pushObjRef(bip.res);
				break;
			case MOD: 
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				bigDiv();
				pushObjRef(bip.rem);
				break;
			case RDINT: // scan return 1 if read value successfully
				if(scanf("%d", &value) == 1) {
					bigFromInt(value);		
					pushObjRef(bip.res);
				} else {
					printf("Error: no digits in input\n");
					exit(1);				
				}
				break;
			case WRINT: 
				bip.op1 = popObjRef();
				bigPrint(stdout);
				break;
			case RDCHR: 
				value = getchar();
				bigFromInt(value);		
				pushObjRef(bip.res);
				break;
			case WRCHR:  
				bip.op1 = popObjRef();
				printf("%c", bigToInt()); 
				break;
			case PUSHG:
				pushg(SIGN_EXTEND(IMMEDIATE(ir))); break;
			case POPG:
				popg(SIGN_EXTEND(IMMEDIATE(ir))); break;
			case ASF:
				pushNumber(fp);
				fp = sp;
				for(int i = 0; i < IMMEDIATE(ir); i++)
					pushObjRef(NULL);
				//sp = sp + IMMEDIATE(ir);
				break;
			case RSF:
				sp = fp;
				fp = popNumber();
				break;
			case PUSHL:
				pushl(SIGN_EXTEND(IMMEDIATE(ir)) + fp); break;
			case POPL:
				popl(fp+SIGN_EXTEND(IMMEDIATE(ir))); break;
			case EQ: // value1 == value2
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				if(bigCmp() == 0)
					bigFromInt(1);
				else
					bigFromInt(0);		
				pushObjRef(bip.res);
				break;
			case NE: // value1 != value2
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				if(bigCmp() == 0)
					bigFromInt(0);
				else
					bigFromInt(1);		
				pushObjRef(bip.res);
				break;
			case LT: // value1 < value2
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				if(bigCmp() < 0)
					bigFromInt(1);
				else
					bigFromInt(0);		
				pushObjRef(bip.res);
				break;
			case LE: // value1 <= value2
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				if(bigCmp() <= 0)
					bigFromInt(1);
				else
					bigFromInt(0);		
				pushObjRef(bip.res);
				break;
			case GT: // value1 > value2
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				if(bigCmp() > 0)
					bigFromInt(1);
				else
					bigFromInt(0);		
				pushObjRef(bip.res);
				break;
			case GE: // value1 >= value2
				bip.op2 = popObjRef();
				bip.op1 = popObjRef();
				if(bigCmp() >= 0)
					bigFromInt(1);
				else
					bigFromInt(0);		
				pushObjRef(bip.res);
				break;
			case JMP: pc = IMMEDIATE(ir); break;
			case BRF: 
				bip.op1 = popObjRef();
				if(bigToInt() == 0)
					pc = IMMEDIATE(ir);
				break;
			case BRT: 
				bip.op1 = popObjRef();
				if(bigToInt() == 1)
					pc = IMMEDIATE(ir);
				break;
			case CALL:		
				pushNumber(pc);
				pc = IMMEDIATE(ir);
				break;
			case RET:
				pc = popNumber();
				break;
			case DROP: 
				value = IMMEDIATE(ir);
				while(value > 0) {
					popObjRef();
					value--;
				}
				break;
			case PUSHR:
				pushObjRef(r[0]); break;
			case POPR:
				r[0] = popObjRef(); break;
			case DUP:
				bip.res = popObjRef();		
				pushObjRef(bip.res);
				pushObjRef(bip.res);
				break;	
			case NEW:
				pushObjRef(newCompoundObject(SIGN_EXTEND(IMMEDIATE(ir))));	
				break;
			case GETF:
				pushObjRef(GET_REFS(popObjRef())[SIGN_EXTEND(IMMEDIATE(ir))]);
				break;
			case PUTF:
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				GET_REFS(bip.op2)[SIGN_EXTEND(IMMEDIATE(ir))] = bip.op1;
				break;
			case NEWA:
				bip.op1 = popObjRef();
				bip.op2 = newCompoundObject(bigToInt());
				pushObjRef(bip.op2);
				break;
			case GETFA:
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				pushObjRef(GET_REFS(bip.op2)[bigToInt()]);
				break;
			case PUTFA:
				bip.res = popObjRef();
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				GET_REFS(bip.op2)[bigToInt()] = bip.res;
				break;	
			case GETSZ:
				bip.op1 = popObjRef();
				if(IS_PRIM(bip.op1))
					bigFromInt(-1);
				else
					bigFromInt(GET_SIZE(bip.op1));
				pushObjRef(bip.res);
				break;
			case PUSHN:
				pushObjRef(NULL);
				break;
			case REFEQ:
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				if(bip.op2 == bip.op1)
					bigFromInt(1);
				else
					bigFromInt(0);;
				pushObjRef(bip.res);
				break;
			case REFNE:
				bip.op1 = popObjRef();
				bip.op2 = popObjRef();
				if(bip.op2 != bip.op1)
					bigFromInt(1);
				else
					bigFromInt(0);
				pushObjRef(bip.res);
				break;
			default: printf("Error in void exec(int ir): ir is something else\n"); break;
		}
}

void memory_is_full(void *x) {
	if(x == NULL) {
			printf("Error: heap overflow\n");
			exit(1);
		}
}

void load_data(char file[]) { 
	r = allocate_header(sizeof(ObjRef));
	memory_is_full(r);

	/*create file pointer*/
	FILE *fp;	

	/*open file*/
	fp = fopen(file, "r");
	if(fp == NULL) {
		printf("Error: cannot open code file '%s'\n", file);
		exit(1);
	} else {
		// read header of the file fp
		if(fread(&buffer, sizeof(header_t), 1, fp) != 1) {
			printf("Error: reading\n");
			exit(1);
		}

		/*Verify the format identifier*/
		if(!strncmp(buffer.name, "NJBF", 4) == 0) {
			printf("identifier invalid\n");
			exit(1);
		}

		/*Verify that this matches the current VM's version number*/
		if(buffer.version != VERSION) {
			printf("Version number doesn't match the version number of VM\n");
			exit(1);
		}
				
		// allocatre memory for Static Data Area
		// warum sizeof(static_data_area) = 8 anstatt 108?
		static_data_area = allocate_header(buffer.sda * sizeof(ObjRef));
		memory_is_full(static_data_area);
		/*if(static_data_area == NULL) {
			printf("memory is full.");
			exit(1);
		}*/

		// allocate memory program memory
		// warum sizeof(ps) = 8 anstatt 108?
		ps = allocate_header(buffer.noi * sizeof(int));
		memory_is_full(ps);
		/*if(ps == NULL) {
			printf("memory is full.");
			exit(1);
		}*/
				
		// read Instruktionen
		if(fread(ps, sizeof(int), buffer.noi, fp) != buffer.noi) {
			printf("Error: reading\n");
			exit(1);
		}

		/*close file*/
		fclose(fp);
	}
}

void read_line(char *str) {
	count = 0;
	char c;

	// result: 
	// maximum one blank
	// write big input without care array size
	while((c = getchar()) != '\n') {		// 10 --> character '\n'

		if(count >= MAX)			// do nothing because array is full
			;
		else if(c != ' ' && c != '\t') {	// check for others character
			str[count] = c;
			count++;
		}
	}
	
	if(count)
		str[count] = '\0';			// end of String terminate by '\0'
	else {
		str[count] = '\n';			// if user doesn't input anything example below
		str[++count] = '\0';			// strncmp("\0", "inspect", 0) = 0 == 0 consequences program continue
	}						
}

void inspect(char *x) {
	void *a = NULL;	
	int j = 0;
	printf("DEBUG [inspect]: stack, data, object?\n");
			
	read_line(x);
	

	if(strncmp(x, "data", count) == 0) {
		for(int i = 0; i < buffer.sda; i++)
			printf("data[%.4d]:\t%d\n", i, *(int*) (static_data_area[i]->data));
		printf("\t--- end of code ---\n");
	} else if(strncmp(x, "stack", count) == 0) {
			if(fp == sp) {
				printf("sp, fp  --->\t%.4d:\t(xxxxxx) xxxxxx\n", fp);
				printf("\t\t--- bottom of stack ---\n");
			} else {
				for(int i = sp; i >= 0; i--) {
					if(i == sp)
						printf("sp\t--->\t%.4d\t(xxxxxx) xxxxxx\n", sp);
					else if(i == fp)
						if(is_objRef(i))
							printf("fp\t--->\t%.4d:\t(objref) %p\n", i, (void*) stack[i].u.objRef);
						else
							printf("fp\t--->\t%.4d:\t(number) %d\n", i, stack[i].u.number);
					else 
						if(is_objRef(i))
							printf("\t\t%.4d:\t(objref) %p\n", i, (void*) stack[i].u.objRef);
						else
							printf("\t\t%.4d:\t(number) %d\n", i, stack[i].u.number);
				}
				printf("\t\t--- bottom of stack ---\n");
			}
	} else if(strncmp(x, "object", count) == 0) {
		printf("object reference?\n");
		scanf("%p", &a);
		while(j < buffer.noi) {
			if(is_objRef(j))
				if(a == (void*) stack[j].u.objRef)
					break;
			j++;
		}
		
		if(IS_PRIM(stack[j].u.objRef)){
			printf("<primitive object>\n");
			bip.op1 = stack[j].u.objRef;
			printf("Value:\t\t%d\n", bigToInt());
			printf("\t--- end of object ---\n");
		}
		getchar();
	}
}

void list(int prog_size) {
	for(int i = 0; i < prog_size; i++) {
		instruktion(i);	
	}
	printf("\t--- end of code ---\n");
}

void break_point(char *x) {
	if(value == -1)
		printf("DEBUG [breakpoint]: cleared\n");
	else
		printf("DEBUG [breakpoint]: set at %d\n", value);
	printf("DEBUG [breakpoint]: address to set, -1 to clear, <ret> for no change?\n");
		
	read_line(x);
	// explicit input 0 because function atoi(int) = 0 if parameter is not a number
	if(strcmp(x, "0") == 0) {
		breakpoint = 0;
		printf("DEBUG [breakpoint]: now set at %d\n", breakpoint);
		return;
	} else if(strcmp(x, "-1") == 0) {
		value = -1;
		printf("DEBUG [breakpoint]: now cleared\n");
		return; 
	}

	// does not include character
	for(int i = 0; i < count; i++)  
		if(x[i] < 48 || x[i] > 57) 		// 48 == '0' ... 57 == '9'
			return;
		
	value = atoi(x);
	if(value < 0 || value > buffer.noi)
		printf("number of instruction = %d\n", buffer.noi);
	else if(value != 0) {
		breakpoint = value;		// important for function run()
		printf("DEBUG [breakpoint]: now set at %d\n", breakpoint);	
	}
}

void run(void) {
	int ir = 0;
	while(!halt) {
		if(pc == breakpoint) {
			index = pc;
			return;
		} else 

		if(step) {
			index = pc;
			return;
		}
		
		if(switcher)
			step = 1;
		ir = ps[pc];
		pc++;
		exec(ir);
	}
	printf("Ninja Virtual Machine stopped\n");
}

void debug(void) {
	// for debug option like (inspect, list, breakpoint, step, run, quit)
	char input[MAX] = "";
	// inspect option like (stack, data, object)
	char x[6] = "";
	unsigned int option = 0;

	instruktion(index);
	printf("DEBUG: inspect, list, breakpoint, step, run, quit?\n");

	read_line(input);
	
	if(strncmp(input, "inspect", count) == 0)
		option = INSPECT;
	else if(strncmp(input, "list", count) == 0)
		option = LIST;
	else if(strncmp(input, "breakpoint", count) == 0)
		option = BREAKPOINT;
	else if(strncmp(input, "step", count) == 0)
		option = STEP;
	else if(strncmp(input, "run", count) == 0)
		option = RUN;
	else if(strncmp(input, "quit", count) == 0)
		option = QUIT;

	switch(option) {
		case INSPECT:
			inspect(x);
			break;
		case LIST:
			list(buffer.noi);
			 break;
		case BREAKPOINT:
			break_point(x);
			break;
		case STEP:
			breakpoint = -1;
			step = 0;
			switcher = 1;
			run();
			break;
		case RUN:
			step = 0;
			switcher = 0;
			run();
			break;
		case QUIT:
			printf("Ninja Virtual Machine stopped\n");
			halt = 1;
			break;
		default: break;
	}
}

int argument(int n, char *argv[], char *str[], int last_argument) {
	int i = 0;
	if(!strcmp(argv[n], str[i++])) {
		if(n == last_argument) {
			printf("Error: stack size is missing\n");
			exit(0);
		} else if(atoi(argv[n+1]) > 0) {
			set_stack_size = atoi(argv[n+1]);
			counter++;		
		} else {
			printf("Error: illegal stack size\n");
			exit(0);
		}
	} else if(!strcmp(argv[n], str[i++])) {
		if(n == last_argument) {
			printf("Error: heap size is missing\n");
			exit(0);
		} else if(atoi(argv[n+1]) > 0) {
			set_heap_size = atoi(argv[n+1]);
			counter++;		
		} else {
			printf("Error: illegal heap size\n");
			exit(0);
		}
	} else if(!strcmp(argv[n], str[i++]))
		;	//--gcstats 
	else if(!strcmp(argv[n], str[i++]))
		;	//--gcpurge
	else if(!strcmp(argv[n], str[i++]))
		start_debug = 1;
	else if(!strcmp(argv[n], str[i++])) {
		printf("Ninja Virtual Machine version %d (compiled %s, %s)\n", VERSION, __DATE__, __TIME__);
			return 1;
		}
	else if(!strcmp(argv[n], str[i++])) {
		printf("usage: ./njvm [options] <code file>\n");
		printf("Option:\n");
		printf("  --stack <n>\t   set stack size to n KBytes (default: n = 64)\n");
		printf("  --heap <n>\t   set heap size to n KBytes (default: n = 8192)\n");
		printf("  --gcstats\t   show garbage collection statistics\n");
		printf("  --gcpurge\t   purge old objects after collection\n");
		printf("  --debug\t   start virtual machine in debug mode\n");
		printf("  --version\t   show version and exit\n");
   		printf("  --help\t   show this help and exit\n");
		return 1;
	} else if(!strncmp(argv[n], "-", 1)) {
		printf("Error: unknown option '%s', try './njvm --help'\n", argv[n]);
		exit(0);
	} else {
		bin++;
		position = n;
		if(bin > 1) {
			printf("Error: more than one code file specified\n");
			return 1;
		}
	}
	return 0;
}

void start_njvm(char *argv) {
	if(set_stack_size > 0) {
		stack = malloc(set_stack_size * 1024);
		max_size = 64 * 1024 / sizeof(Stackslot);
		memory_is_full(stack);
	} else {
		stack = malloc(64 * 1024);
		max_size = 64 * 1024 / sizeof(Stackslot);
		memory_is_full(stack);
	}

	if(set_heap_size > 0) {
		halfsize = set_heap_size * 512;
		heap = malloc(set_heap_size * 1024);
		//printf("heap = %p\n", heap);
		ziel_halbspeicher = heap;
		//printf("ziel_halbspeicher = %p\n", ziel_halbspeicher);
		memory_is_full(ziel_halbspeicher);
		quell_halbspeicher = ziel_halbspeicher + halfsize;
		memory_is_full(quell_halbspeicher);
	} else {
		halfsize = 8192 * 512;
		heap = malloc(8192 * 1024);
		//printf("heap = %p\n", heap);
		ziel_halbspeicher = heap;
		//printf("ziel_halbspeicher = %p\n", ziel_halbspeicher);
		memory_is_full(ziel_halbspeicher);
		quell_halbspeicher = ziel_halbspeicher + halfsize;
		memory_is_full(quell_halbspeicher);
	}

	if(start_debug && bin == 1) {
		load_data(argv);
		printf("DEBUG: file   :  '%s'\n", argv);
		printf("       code   :  %d instructions\n", buffer.noi);
		printf("       data   :  %d objects\n", buffer.sda);
		printf("       stack  :  %d slots\n", max_size);
		printf("       heap   :  2 * %d bytes\n", halfsize);
		printf("Ninja Virtual Machine started\n");
		while(!halt) {
			debug();			
		}
	} else if(bin == 1) {
		//printf("start programm\n");
		load_data(argv);

		printf("Ninja Virtual Machine started\n");
		
		// start program
		step = 0;
		switcher = 0;
		run();
			
		// release memory from ps
		//free(ps);

		// release memory from static_data_area
		//free(static_data_area);
	} else if(bin == 0)
		printf("Error: no code file specified\n");
}

int main(int argc, char *argv[]) {
	char *str[7]; 
	str[0] = "--stack";
	str[1] = "--heap";
	str[2] = "--gcstats";
	str[3] = "--gcpurge";
	str[4] = "--debug"; 
	str[5] = "--version";
	str[6] = "--help";
	int stopp = 1;

	if(argc == 1)
		printf("Error: no code file specified\n");
	else if(argc == 2) {
		argument( 1, argv, str, 1);
		start_njvm(argv[position]);
	} else if(argc > 2) {
		for(counter = 1; counter < argc; counter++) 
			if(argument(counter, argv, str, argc-1)) {
				stopp = 0;
				break;
			}
		
		if(stopp)
			start_njvm(argv[position]);
	} 
	return 0;
}
